export interface Batch {
  id: string;
  eventId: string;
  name: string;
  price: number;
  quantity: number;
}
